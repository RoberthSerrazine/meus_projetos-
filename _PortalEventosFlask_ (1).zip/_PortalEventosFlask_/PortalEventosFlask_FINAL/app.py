from datetime import datetime
from flask import Flask, render_template, abort

app = Flask(__name__)



palestrantes = {
    1: {"id": 1, "nome": "Roberth Serrazine", "foto": "roberth.jpg",
        "bio": "Músico, luthier e empreendedor. Dono de loja de instrumentos e performer noturno."},
    2: {"id": 2, "nome": "Gabi Sarmento", "foto": "gabi.jpg",
        "bio": "Estudante de Moda e criadora de conteúdo. Moda acessível, branding pessoal e social media."},
    3: {"id": 3, "nome": "Ana Pâmara", "foto": "ana.jpg",
        "bio": "Medica, Área da saúde. Foco em gravidez, rotina de estudos e bem-estar acadêmico."},
}

categorias = ["Tecnologia","Negócios","Música","Moda","Saúde","Educação"]


eventos = {
    201: {"id":201,"nome":"Música & Empreender: da Paixão ao Negócio",
          "data":"2025-11-05 19:00","local":"Auditório Central — Bloco A",
          "banner":"https://via.placeholder.com/800x300.png?text=Musica+%26+Empreender",
          "descricao":"Como transformar tocar na noite e vender instrumentos em um negócio sustentável.",
          "palestrantes":[1],"categoria":"Negócios"},
    202: {"id":202,"nome":"Luthieria Essencial: Regulagem que Paga as Contas",
          "data":"2025-11-07 18:30","local":"Laboratório de Música — Bloco B, Sala 105",
          "banner":"https://via.placeholder.com/800x300.png?text=Luthieria+Essencial",
          "descricao":"Setups rápidos (tensor, ação, oitavas), troca de captadores e manutenção que gera renda.",
          "palestrantes":[1],"categoria":"Música"},
    203: {"id":203,"nome":"Moda Acessível para Universitários",
          "data":"2025-11-10 17:00","local":"Sala Multiuso — Bloco C, 2º andar",
          "banner":"https://via.placeholder.com/800x300.png?text=Moda+Acessivel",
          "descricao":"Como montar looks com pouco orçamento, brechó inteligente e imagem profissional.",
          "palestrantes":[2],"categoria":"Moda"},
    204: {"id":204,"nome":"Social Media para Marcas de Moda Independentes",
          "data":"2025-11-11 19:00","local":"Auditório 2 — Bloco A",
          "banner":"https://via.placeholder.com/800x300.png?text=Moda+%26+Social+Media",
          "descricao":"Planejamento de conteúdo, collabs, calendário editorial e conversão.",
          "palestrantes":[2],"categoria":"Moda"},
    205: {"id":205,"nome":"Gravidez & Estudos: Conciliação Realista",
          "data":"2025-11-12 18:00","local":"Sala 203 — Bloco D",
          "banner":"https://via.placeholder.com/800x300.png?text=Gravidez+%26+Estudos",
          "descricao":"Organização, rede de apoio, direitos acadêmicos e comunicação com professores.",
          "palestrantes":[3],"categoria":"Saúde"},
    206: {"id":206,"nome":"Saúde Mental na Faculdade: Pressão, Ansiedade e Rotina",
          "data":"2025-11-14 09:00","local":"Lab 204 — Bloco B",
          "banner":"https://via.placeholder.com/800x300.png?text=Saude+Mental+no+Campus",
          "descricao":"Higiene do sono, limites, hábitos e como buscar ajuda no campus.",
          "palestrantes":[3],"categoria":"Saúde"},
    207: {"id":207,"nome":"Semana da Tecnologia — Demo Flask",
          "data":"2025-11-15 19:00","local":"Auditório Central — Bloco A",
          "banner":"https://via.placeholder.com/800x300.png?text=Semana+da+Tecnologia",
          "descricao":"Roteamento, templates e dados fixos com Flask — mini showcase do projeto.",
          "palestrantes":[1,2],"categoria":"Tecnologia"},
}

def parse_dt(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M")
    except Exception:
        return None


@app.route("/")
def index():
    evs = sorted(eventos.values(), key=lambda e: parse_dt(e["data"]) or datetime.max)
    return render_template("index.html", eventos=evs)

@app.route("/evento/<int:evento_id>")
def evento_detail(evento_id):
    ev = eventos.get(evento_id)
    if not ev:
        abort(404)
    pales = [p for pid, p in palestrantes.items() if pid in ev["palestrantes"]]
    return render_template("evento.html", evento=ev, palestrantes=pales)

@app.route("/categorias")
def lista_categorias():
    mapa = {c: [] for c in categorias}
    for e in eventos.values():
        mapa.setdefault(e["categoria"], []).append(e)
    return render_template("categorias.html", categorias=categorias, mapa=mapa)

@app.route("/palestrantes")
def lista_palestrantes():
    pales = []
    for p in palestrantes.values():
        evs = [e for e in eventos.values() if p["id"] in e["palestrantes"]]
        pales.append((p, evs))
    return render_template("palestrantes.html", palestrantes=pales)

if __name__ == "__main__":
    app.run(debug=True)
