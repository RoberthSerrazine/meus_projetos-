from flask import Flask, render_template

app = Flask(__name__)

BANDAS = [
    {
        "id": 1,
        "nome": "Metallica",
        "estilo": "Metal",
        "foto": "static/img/metallica.png",
        "descricao": "Metallica é uma das maiores bandas de heavy metal do mundo.",
        "musicas": [
            {"nome": "Enter Sandman", "album": "Metallica", "ano": 1991},
            {"nome": "Nothing Else Matters", "album": "Metallica", "ano": 1991}
        ],
        "comentarios": [
            {"autor": "João", "texto": "Clássicos eternos!"},
            {"autor": "Maria", "texto": "Show incrível no Rock in Rio."}
        ]
    },
    {
        "id": 2,
        "nome": "Coldplay",
        "estilo": "Pop Rock",
        "foto": "static/img/coldplay.png",
        "descricao": "Coldplay é uma banda britânica de pop rock formada em 1996.",
        "musicas": [
            {"nome": "Yellow", "album": "Parachutes", "ano": 2000},
            {"nome": "Viva la Vida", "album": "Viva la Vida", "ano": 2008}
        ],
        "comentarios": [
            {"autor": "Carlos", "texto": "Uma das melhores bandas da atualidade."},
            {"autor": "Ana", "texto": "Yellow é minha favorita!"}
        ]
    },
    {
        "id": 3,
        "nome": "Legião Urbana",
        "estilo": "Rock Nacional",
        "foto": "static/img/legiao.png",
        "descricao": "Legião Urbana foi uma das bandas mais influentes do rock brasileiro.",
        "musicas": [
            {"nome": "Tempo Perdido", "album": "Dois", "ano": 1986},
            {"nome": "Pais e Filhos", "album": "As Quatro Estações", "ano": 1989}
        ],
        "comentarios": [
            {"autor": "Pedro", "texto": "Renato Russo é uma lenda."},
            {"autor": "Fernanda", "texto": "As letras são poesia pura."}
        ]
    }
]

@app.route("/")
def home():
    return render_template("index.html", bandas=BANDAS)

@app.route("/banda/<int:id>")
def detalhes(id):
    banda = next((b for b in BANDAS if b["id"] == id), None)
    return render_template("detalhes.html", banda=banda)

if __name__ == "__main__":
    app.run(debug=True)
