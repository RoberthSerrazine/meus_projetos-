package br.com.roberth.singleton;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoggerTest {

    @Test
    void testSingletonInstance() {
        SingletonLogger logger1 = SingletonLogger.getInstance();
        SingletonLogger logger2 = SingletonLogger.getInstance();
        assertSame(logger1, logger2, "As instâncias devem ser iguais (única instância)");
    }

    @Test
    void testLogOutput() {
        SingletonLogger logger = SingletonLogger.getInstance();
        String msg = "Hello Singleton";
        assertEquals("[LOG]: " + msg, logger.log(msg));
    }
}
