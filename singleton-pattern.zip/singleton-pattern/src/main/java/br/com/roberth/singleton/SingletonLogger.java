package br.com.roberth.singleton;

/**
 * Classe Singleton.
 * Garante que apenas uma instância de Logger exista na aplicação.
 */
public class SingletonLogger {

    // instância única (lazy initialization)
    private static SingletonLogger instance;

    // construtor privado: impede new SingletonLogger()
    private SingletonLogger() {}

    // método de acesso global
    public static synchronized SingletonLogger getInstance() {
        if (instance == null) {
            instance = new SingletonLogger();
        }
        return instance;
    }

    // método de exemplo
    public String log(String message) {
        return "[LOG]: " + message;
    }
}
