# Padrão Singleton (Java + JUnit)

## O que é?
O padrão **Singleton** garante que uma classe tenha **apenas uma instância** em toda a aplicação, 
e fornece um ponto de acesso global a ela.

## Estrutura no código
- `SingletonLogger` → Classe Singleton com instância única.
- `LoggerTest` → Testes unitários com JUnit.

## Como rodar
1. Instale **JDK 17+** e **Maven**.
2. No terminal, na pasta do projeto:
   ```bash
   mvn test
   ```

## Exemplo de uso
```java
SingletonLogger logger = SingletonLogger.getInstance();
System.out.println(logger.log("Teste de log"));
```
Saída:
```
[LOG]: Teste de log
```
