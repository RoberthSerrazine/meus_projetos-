from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html", titulo="Início")

@app.route("/sobre")
def sobre():
    return render_template("sobre.html", titulo="Sobre")

@app.route("/contato", methods=["GET", "POST"])
def contato():
    if request.method == "POST":
        nome = request.form["nome"]
        data = request.form["data"]
        hora = request.form["hora"]
        motivo = request.form["motivo"]
        medico = request.form["medico"]

        return render_template("ficha.html", 
                               titulo="Ficha da Consulta",
                               nome=nome, data=data, hora=hora, 
                               motivo=motivo, medico=medico)
    return render_template("contato.html", titulo="Agende sua consulta")

if __name__ == "__main__":
    app.run(debug=True)
