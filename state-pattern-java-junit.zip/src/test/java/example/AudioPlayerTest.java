package example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AudioPlayerTest {

    @Test
    void startsStopped() {
        AudioPlayer p = new AudioPlayer();
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());
        assertEquals("STOPPED", p.getState().toString());
    }

    @Test
    void stopped_to_playing_on_play() {
        AudioPlayer p = new AudioPlayer();
        p.play();
        assertEquals("PlayingState", p.getState().getClass().getSimpleName());
        assertEquals("PLAYING", p.getState().toString());
    }

    @Test
    void playing_to_paused_on_pause() {
        AudioPlayer p = new AudioPlayer();
        p.play();   // Stopped -> Playing
        p.pause();  // Playing -> Paused
        assertEquals("PausedState", p.getState().getClass().getSimpleName());
        assertEquals("PAUSED", p.getState().toString());
    }

    @Test
    void paused_to_playing_on_play() {
        AudioPlayer p = new AudioPlayer();
        p.play();
        p.pause();
        p.play();
        assertEquals("PlayingState", p.getState().getClass().getSimpleName());
    }

    @Test
    void playing_to_stopped_on_stop() {
        AudioPlayer p = new AudioPlayer();
        p.play();
        p.stop();
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());
    }

    @Test
    void paused_to_stopped_on_stop() {
        AudioPlayer p = new AudioPlayer();
        p.play();
        p.pause();
        p.stop();
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());
    }

    @Test
    void stopping_when_stopped_is_idempotent() {
        AudioPlayer p = new AudioPlayer();
        p.stop();
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());
    }

    @Test
    void cannot_pause_when_stopped() {
        AudioPlayer p = new AudioPlayer();
        IllegalTransitionException ex = assertThrows(
            IllegalTransitionException.class,
            p::pause
        );
        assertTrue(ex.getMessage().contains("Não dá pra pausar"));
    }

    @Test
    void play_when_playing_is_idempotent() {
        AudioPlayer p = new AudioPlayer();
        p.play();
        p.play(); // não muda o estado
        assertEquals("PlayingState", p.getState().getClass().getSimpleName());
    }

    @Test
    void pause_when_paused_is_idempotent() {
        AudioPlayer p = new AudioPlayer();
        p.play();
        p.pause();
        p.pause(); // continua pausado
        assertEquals("PausedState", p.getState().getSimpleName());
    }
}
