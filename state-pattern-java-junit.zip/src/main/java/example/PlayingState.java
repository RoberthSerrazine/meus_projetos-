package example;

public class PlayingState implements State {
    @Override
    public void play(AudioPlayer ctx) {
        // idempotente: já tocando
    }

    @Override
    public void pause(AudioPlayer ctx) {
        ctx.pausePlayback();
        ctx.setState(new PausedState());
    }

    @Override
    public void stop(AudioPlayer ctx) {
        ctx.stopPlayback();
        ctx.setState(new StoppedState());
    }

    @Override
    public String toString() { return "PLAYING"; }
}
