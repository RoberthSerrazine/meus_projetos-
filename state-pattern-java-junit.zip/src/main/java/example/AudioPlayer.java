package example;

public class AudioPlayer {
    private State state;

    public AudioPlayer() {
        this.state = new StoppedState();
    }

    void setState(State state) { this.state = state; }

    public State getState() { return state; }

    // API pública delega para o estado atual
    public void play()  { state.play(this);  }
    public void pause() { state.pause(this); }
    public void stop()  { state.stop(this);  }

    // utils pra demo (ex.: aciona motor de áudio)
    void startPlayback() { /* inicia o som */ }
    void pausePlayback() { /* pausa o som  */ }
    void stopPlayback()  { /* para o som   */ }
}
