# State Pattern em Java + JUnit

Projeto de exemplo mostrando o padrão de projeto State para um `AudioPlayer` com estados `Stopped`, `Playing` e `Paused`, e testes em JUnit 5.

## Estrutura
- `src/main/java/example/*`: código de produção
- `src/test/java/example/*`: testes JUnit 5

## Rodando os testes
Use sua stack preferida. Exemplos:

### Maven
```xml
<!-- pom.xml mínimo -->
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>example</groupId>
  <artifactId>state-pattern</artifactId>
  <version>1.0.0</version>
  <properties>
    <maven.compiler.source>17</maven.compiler.source>
    <maven.compiler.target>17</maven.compiler.target>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <junit.jupiter.version>5.10.2</junit.jupiter.version>
  </properties>
  <dependencies>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <version>${junit.jupiter.version}</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-surefire-plugin</artifactId>
        <version>3.1.2</version>
        <configuration>
          <useModulePath>false</useModulePath>
        </configuration>
      </plugin>
    </plugins>
  </build>
</project>
```

Rode:
```bash
mvn -q -Dtest=example.AudioPlayerTest test
```

### Gradle (Kotlin DSL)
```kotlin
// build.gradle.kts mínimo
plugins { java }
repositories { mavenCentral() }
dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.2")
}
tasks.test {
    useJUnitPlatform()
}
java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}
```

Rode:
```bash
./gradlew test --tests example.AudioPlayerTest
```
