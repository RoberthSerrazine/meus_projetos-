package example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class AudioPlayer {
    private State state;
    private final List<PlayerObserver> observers = new ArrayList<>();

    public AudioPlayer() {
        this.state = new StoppedState();
    }

    void setState(State next) {
        if (!Objects.equals(this.state.getClass(), next.getClass())) {
            this.state = next;
            notifyObservers(PlayerEvent.STATE_CHANGED);
        } else {
            this.state = next; // idempotente
        }
    }

    public State getState() { return state; }

    // API pública delega para o estado atual e emite eventos de intenção
    public void play()  { notifyObservers(PlayerEvent.PLAY_REQUEST);  state.play(this);  }
    public void pause() { notifyObservers(PlayerEvent.PAUSE_REQUEST); state.pause(this); }
    public void stop()  { notifyObservers(PlayerEvent.STOP_REQUEST);  state.stop(this);  }

    // utils pra demo (ex.: aciona motor de áudio)
    void startPlayback() { /* inicia o som */ }
    void pausePlayback() { /* pausa o som  */ }
    void stopPlayback()  { /* para o som   */ }

    // ==== Observer (Subject) ====
    public void addObserver(PlayerObserver o) {
        if (o != null && !observers.contains(o)) observers.add(o);
    }
    public void removeObserver(PlayerObserver o) {
        observers.remove(o);
    }
    public List<PlayerObserver> getObservers() {
        return Collections.unmodifiableList(observers);
    }
    void notifyObservers(PlayerEvent event) {
        for (PlayerObserver o : observers) { o.onEvent(this, event); }
    }
}
