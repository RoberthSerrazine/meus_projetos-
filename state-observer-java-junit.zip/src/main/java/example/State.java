package example;

public interface State {
    void play(AudioPlayer ctx);   // começar ou retomar
    void pause(AudioPlayer ctx);  // pausar
    void stop(AudioPlayer ctx);   // parar
    default String name() { return this.getClass().getSimpleName(); }
}
