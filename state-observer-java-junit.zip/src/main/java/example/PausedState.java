package example;

public class PausedState implements State {
    @Override
    public void play(AudioPlayer ctx) {
        ctx.startPlayback();
        ctx.setState(new PlayingState());
    }

    @Override
    public void pause(AudioPlayer ctx) {
        // idempotente: já pausado
    }

    @Override
    public void stop(AudioPlayer ctx) {
        ctx.stopPlayback();
        ctx.setState(new StoppedState());
    }

    @Override
    public String toString() { return "PAUSED"; }
}
