package example;

/** Observer que recebe eventos do AudioPlayer (Subject). */
public interface PlayerObserver {
    void onEvent(AudioPlayer source, PlayerEvent event);
}
