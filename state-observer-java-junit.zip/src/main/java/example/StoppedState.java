package example;

public class StoppedState implements State {
    @Override
    public void play(AudioPlayer ctx) {
        ctx.startPlayback();
        ctx.setState(new PlayingState());
    }

    @Override
    public void pause(AudioPlayer ctx) {
        throw new IllegalTransitionException("Não dá pra pausar: já está parado.");
    }

    @Override
    public void stop(AudioPlayer ctx) {
        // idempotente: continuar parado é ok
    }

    @Override
    public String toString() { return "STOPPED"; }
}
