package example;

import java.util.ArrayList;
import java.util.List;

/** Observer simples que registra os eventos recebidos em memória. */
public class LoggingObserver implements PlayerObserver {
    private final List<PlayerEvent> events = new ArrayList<>();

    @Override
    public void onEvent(AudioPlayer source, PlayerEvent event) {
        events.add(event);
    }

    public List<PlayerEvent> getEvents() {
        return List.copyOf(events);
    }

    public void clear() { events.clear(); }
}
