package example;

/** Tipos de eventos do player a serem notificados para observers. */
public enum PlayerEvent {
    PLAY_REQUEST,
    PAUSE_REQUEST,
    STOP_REQUEST,
    STATE_CHANGED // disparado após alteração efetiva de estado
}
