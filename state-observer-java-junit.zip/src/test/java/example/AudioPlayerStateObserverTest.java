package example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class AudioPlayerStateObserverTest {

    @Test
    void startsStopped() {
        AudioPlayer p = new AudioPlayer();
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());
        assertEquals("STOPPED", p.getState().toString());
    }

    @Test
    void state_transitions_and_observer_notifications() {
        AudioPlayer p = new AudioPlayer();
        LoggingObserver obs = new LoggingObserver();
        p.addObserver(obs);

        // Stopped -> play()
        p.play();
        assertEquals("PlayingState", p.getState().getClass().getSimpleName());

        // Playing -> pause()
        p.pause();
        assertEquals("PausedState", p.getState().getClass().getSimpleName());

        // Paused -> play() (volta a tocar)
        p.play();
        assertEquals("PlayingState", p.getState().getClass().getSimpleName());

        // Playing -> stop()
        p.stop();
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());

        // Verifica sequência de eventos recebidos
        List<PlayerEvent> expected = List.of(
            PlayerEvent.PLAY_REQUEST,
            PlayerEvent.STATE_CHANGED,

            PlayerEvent.PAUSE_REQUEST,
            PlayerEvent.STATE_CHANGED,

            PlayerEvent.PLAY_REQUEST,
            PlayerEvent.STATE_CHANGED,

            PlayerEvent.STOP_REQUEST,
            PlayerEvent.STATE_CHANGED
        );
        assertEquals(expected, obs.getEvents());
    }

    @Test
    void idempotent_actions_do_not_emit_state_changed() {
        AudioPlayer p = new AudioPlayer();
        LoggingObserver obs = new LoggingObserver();
        p.addObserver(obs);

        p.stop(); // já está parado: deve emitir STOP_REQUEST mas não STATE_CHANGED
        assertEquals("StoppedState", p.getState().getClass().getSimpleName());

        // Agora play() e play() de novo (idempotente)
        p.play();
        p.play();
        assertEquals("PlayingState", p.getState().getClass().getSimpleName());

        List<PlayerEvent> expected = List.of(
            PlayerEvent.STOP_REQUEST,
            PlayerEvent.PLAY_REQUEST,
            PlayerEvent.STATE_CHANGED,
            PlayerEvent.PLAY_REQUEST
        );
        assertEquals(expected, obs.getEvents());
    }

    @Test
    void cannot_pause_when_stopped_emits_intent_then_exception() {
        AudioPlayer p = new AudioPlayer();
        LoggingObserver obs = new LoggingObserver();
        p.addObserver(obs);

        IllegalTransitionException ex = assertThrows(
            IllegalTransitionException.class,
            p::pause
        );
        assertTrue(ex.getMessage().contains("Não dá pra pausar"));

        assertEquals(List.of(PlayerEvent.PAUSE_REQUEST), obs.getEvents());
    }

    @Test
    void remove_observer_stops_receiving_events() {
        AudioPlayer p = new AudioPlayer();
        LoggingObserver obs = new LoggingObserver();
        p.addObserver(obs);
        p.removeObserver(obs);

        p.play();
        assertTrue(obs.getEvents().isEmpty());
    }
}
