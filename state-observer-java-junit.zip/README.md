# State + Observer em Java (JUnit 5)

Exemplo completo combinando **State** (encapsula comportamento por estado)
com **Observer** (reage a eventos e transições).

## Fluxo de eventos
- Antes de delegar ao estado: `PLAY_REQUEST`, `PAUSE_REQUEST`, `STOP_REQUEST`.
- Ao mudar de fato de estado: `STATE_CHANGED`.

## Rodando testes

### Maven (pom.xml incluso)
```bash
mvn -q -Dtest=example.AudioPlayerStateObserverTest test
```

### Gradle (build.gradle.kts incluso)
```bash
./gradlew test --tests example.AudioPlayerStateObserverTest
```
